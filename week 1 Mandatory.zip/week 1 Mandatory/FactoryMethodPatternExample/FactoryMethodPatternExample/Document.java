package FactoryMethodPatternExample;

// Step 2: Document Interface
public interface Document {
    void open();
}
